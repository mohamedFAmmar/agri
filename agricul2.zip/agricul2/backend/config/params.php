<?php
return [
    'adminEmail' => 'admin@example.com',
    'token_expiry' => 86400 * 10, // 10 days
    'file_size' => 1048576, // 1MB,
    'file_ext' => ['jpg', 'png', 'gif']
];
