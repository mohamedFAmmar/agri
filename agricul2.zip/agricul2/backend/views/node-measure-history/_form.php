<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\NodeMeasurehistory */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="node-measure-history-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'node_code')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'measure_code')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'measure_type')->dropDownList($model->getMeasureTypeList())?>

    <?= $form->field($model, 'value')->textInput() ?>

    <?= $form->field($model, 'min_value')->textInput() ?>

    <?= $form->field($model, 'max_value')->textInput() ?>

    <?= $form->field($model, 'status')->dropDownList($model->getStatusList())?>

    <?= $form->field($model, 'date')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton(Yii::t('app', 'Save'), ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
