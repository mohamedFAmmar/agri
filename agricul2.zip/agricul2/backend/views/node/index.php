<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
/* @var $this yii\web\View */
/* @var $searchModel app\models\NodeSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Nodes');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="node-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php Pjax::begin(); ?>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a(Yii::t('app', 'Create Node'), ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            //'id',
            'code',
            'title',
            'lng',
            'lat',
            [
                'attribute'=>'status',
                'value'=>function ($data){
                    return $data->getStatusList($data->status);   
                },
                'filter'=>$searchModel->getStatusList(),
            ],
            'created:date',
            'updated:date',
           /* [
                'attribute'=>'created_by',
                'value'=>function ($data){
                    return $data->getCreatedBy();   
                },
                'filter'=>$searchModel->getStatusList(),
            ],*/

            [
                'attribute'=>'created_by',
            //    'value'=>'($data->createdBy)?$data->createdBy->username:""'
            ],
            [
                'attribute'=>'updated_by',
            //    'value'=>'($data->updatedBy)?$data->updatedBy->username:""'
            ],

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
    <?php Pjax::end(); ?>
</div>
