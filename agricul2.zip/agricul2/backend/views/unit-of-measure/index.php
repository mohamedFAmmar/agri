<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
/* @var $this yii\web\View */
/* @var $searchModel app\models\UnitOfMeasureSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Unit Of Measures');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="unit-of-measure-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php Pjax::begin(); ?>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a(Yii::t('app', 'Create Unit Of Measure'), ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id',
            'code',
            'title',
            [
                'attribute'=>'type',
                'value'=>function ($data){
                    return $data->getTypeList($data->type);   
                },
                'filter'=>$searchModel->getTypeList(),
            ],
             [
                'attribute'=>'status',
                'value'=>function ($data){
                    return $data->getStatusList($data->status);   
                },
                'filter'=>$searchModel->getStatusList(),
            ],
           // 'chart_type',
            'alias',
            'created:date',
            'updated:date',
            [
                'attribute'=>'created_by',
                //'value'=>'($data->createdBy)?$data->createdBy->username:""'
            ],
            [
                'attribute'=>'updated_by',
                //'value'=>'($data->updatedBy)?$data->updatedBy->username:""'
            ],


            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
    <?php Pjax::end(); ?>
</div>
