<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
/* @var $this yii\web\View */
/* @var $searchModel app\models\NodeMeasureSettingsSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Node Measure Settings');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="node-measure-settings-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php Pjax::begin(); ?>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a(Yii::t('app', 'Create Node Measure Settings'), ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

           // 'id',
            'node_code',
            'measure_code',
            [
                'attribute'=>'measure_type',
                'value'=>function ($data){
                    return $data->getMeasureTypeList($data->measure_type);   
                },
                'filter'=>$searchModel->getMeasureTypeList(),
            ],
            'value',
            'min_value',
            'max_value',
            
             [
                'attribute'=>'status',
                'value'=>function ($data){
                    return $data->getStatusList($data->status);   
                },
                'filter'=>$searchModel->getStatusList(),
            ],
            'created:date',
            'updated:date',
            [
                'attribute'=>'created_by',
                //'value'=>'($data->createdBy)?$data->createdBy->username:""'
            ],
            [
                'attribute'=>'updated_by',
                //'value'=>'($data->updatedBy)?$data->updatedBy->username:""'
            ],

            'date:date',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
    <?php Pjax::end(); ?>
</div>
