<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "node".
 *
 * @property int $id
 * @property string $code
 * @property string $title
 * @property int $lng
 * @property int $lat
 * @property int $status
 * @property string $created
 * @property string $updated
 * @property int $created_by
 * @property int $updated_by
 *
 * @property NodeMeasureHistory[] $nodeMeasureHistories
 * @property NodeMeasureSettings[] $nodeMeasureSettings
 */
class Node extends \yii\db\ActiveRecord
{
    const INACTIVE = 0;
    const ACTIVE = 1;
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'node';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['code', 'title', 'lng', 'lat'], 'required'],
            [['lng', 'lat', 'created_by', 'updated_by'], 'integer'],
            [['created', 'updated'], 'safe'],
            [['code', 'title'], 'string', 'max' => 255],
            [['status'], 'string', 'max' => 1],
            [['code'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'code' => Yii::t('app', 'Code'),
            'title' => Yii::t('app', 'Title'),
            'lng' => Yii::t('app', 'Lng'),
            'lat' => Yii::t('app', 'Lat'),
            'status' => Yii::t('app', 'Status'),
            'created' => Yii::t('app', 'Created'),
            'updated' => Yii::t('app', 'Updated'),
            'created_by' => Yii::t('app', 'Created By'),
            'updated_by' => Yii::t('app', 'Updated By'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNodeMeasureHistories()
    {
        return $this->hasMany(NodeMeasureHistory::className(), ['node_code' => 'code']);
    }
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNodeMeasureSettings()
    {
        return $this->hasMany(NodeMeasureSettings::className(), ['node_code' => 'code']);
    }
     /**
     * @inheritdoc
     */
    public function beforeSave($insert)
    {
        if($insert){
            $this->created=date("Y-m-d H:i:s");
            $this->created_by=yii::$app->user->id;
        }
        $this->updated=date("Y-m-d H:i:s");
        $this->updated_by=yii::$app->user->id;
        return parent::beforeSave($insert);
    }
     /**
     * @return \yii\db\ActiveQuery
     */
    public function getStatusList($value='')
    {
        $list=[0=>Yii::t('app', 'Not Active'),1=>Yii::t('app', 'Active')];
        return ($value!='')?$list[$value]:$list;
    }
    /**
     * Finds user by code
     *
     * @param string $code
     * @return static|null
     */
    public static function findByCode($code)
    {
        return static::find()->where(
            'code = :code and status = :status', [
                ':code' => $code,
                ':status' => self::ACTIVE
            ])->one();
    }

    public function getColumns(){
        $columns = [];
        $fields = $this->attributeLabels();
        unset($fields['id']);
        foreach ($fields as $field => $label) {
            $filterItems=[];
            switch ($field) {
                case 'status':
                    $filterItems=$this->getStatusList();
                    break;
                case 'created_by':
                case 'updated_by':
                    $filterItems=[];
                    break;
                default:
                    # code...
                    break;
            }
            array_push($columns, [
                "label"=>$label,
                "attribute"=> $field,
                "description"=> null,
                "options"=> [],
                "sortable"=>true,
                "filterable"=> true,
                "filter"=>[
                    "selected"=>null,
                    "items"=> $filterItems,
                    "options"=> []
                ],
                "header"=> [
                    "value"=> [],
                    "options"=> []
                ],
                "footer"=>[
                    "value"=> [],
                    "options"=> []
                ]
            ]);
        }
        return $columns; 
    }
}
