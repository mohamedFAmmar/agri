<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "node_measure_settings".
 *
 * @property string $id
 * @property string $node_code
 * @property string $measure_code
 * @property int $measure_type
 * @property double $value
 * @property double $min_value
 * @property double $max_value
 * @property int $status
 * @property string $created
 * @property string $updated
 * @property int $created_by
 * @property int $updated_by
 * @property string $date
 *
 * @property Node $nodeCode
 * @property UnitOfMeasure $measureCode
 * @property User $createdBy
 * @property User $updatedBy
 */
class NodeMeasureSettings extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'node_measure_settings';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['node_code', 'measure_code', 'min_value', 'max_value', 'date'], 'required'],
            [['value', 'min_value', 'max_value'], 'number'],
            [['created', 'updated', 'date'], 'safe'],
            [['created_by', 'updated_by'], 'integer'],
            [['node_code', 'measure_code'], 'string', 'max' => 255],
            [['measure_type', 'status'], 'string', 'max' => 1],
            [['node_code'], 'exist', 'skipOnError' => true, 'targetClass' => Node::className(), 'targetAttribute' => ['node_code' => 'code']],
            [['measure_code'], 'exist', 'skipOnError' => true, 'targetClass' => UnitOfMeasure::className(), 'targetAttribute' => ['measure_code' => 'code']],
            [['created_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['created_by' => 'id']],
            [['updated_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['updated_by' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'node_code' => Yii::t('app', 'Node Code'),
            'measure_code' => Yii::t('app', 'Measure Code'),
            'measure_type' => Yii::t('app', 'Measure Type'),
            'value' => Yii::t('app', 'Value'),
            'min_value' => Yii::t('app', 'Min Value'),
            'max_value' => Yii::t('app', 'Max Value'),
            'status' => Yii::t('app', 'Status'),
            'created' => Yii::t('app', 'Created'),
            'updated' => Yii::t('app', 'Updated'),
            'created_by' => Yii::t('app', 'Created By'),
            'updated_by' => Yii::t('app', 'Updated By'),
            'date' => Yii::t('app', 'Date'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNodeCode()
    {
        return $this->hasOne(Node::className(), ['code' => 'node_code']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getMeasureCode()
    {
        return $this->hasOne(UnitOfMeasure::className(), ['code' => 'measure_code']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'created_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'updated_by']);
    }
     /**
     * @inheritdoc
     */
    public function beforeSave($insert)
    {
        if($insert){
            $this->created=date("Y-m-d H:i:s");
            $this->created_by=yii::$app->user->id;
        }
        $this->updated=date("Y-m-d H:i:s");
        $this->updated_by=yii::$app->user->id;
        return parent::beforeSave($insert);
    }
     /**
     * @return \yii\db\ActiveQuery
     */
    public function getStatusList($value='')
    {
        $list=[0=>Yii::t('app', 'Not Active'),1=>Yii::t('app', 'Active')];
        return ($value!='')?$list[$value]:$list;
    }
       /**
     * @return \yii\db\ActiveQuery
     */
    public function getMeasureTypeList($value='')
    {
        $list=[0=>Yii::t('app', 'Sensor'),1=>Yii::t('app', 'Actuator')];
        return ($value!=='')?$list[$value]:$list;
    }
}
