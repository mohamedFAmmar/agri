<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "unit_of_measure".
 *
 * @property int $id
 * @property string $code
 * @property string $title
 * @property int $type 0=sensor , 1=actuator
 * @property int $status
 * @property string $chart_type
 * @property string $alias
 * @property string $created
 * @property string $updated
 * @property int $created_by
 * @property int $updated_by
 *
 * @property NodeMeasureHistory[] $nodeMeasureHistories
 * @property NodeMeasureSettings[] $nodeMeasureSettings
 */
class UnitOfMeasure extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'unit_of_measure';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['code', 'title', 'alias'], 'required'],
            [['created', 'updated', 'chart_type'], 'safe'],
            [['created_by', 'updated_by'], 'integer'],
            [['code', 'title', 'chart_type', 'alias'], 'string', 'max' => 255],
            [['type', 'status'], 'string', 'max' => 1],
            [['code'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'code' => Yii::t('app', 'Code'),
            'title' => Yii::t('app', 'Title'),
            'type' => Yii::t('app', 'Type'),
            'status' => Yii::t('app', 'Status'),
            'chart_type' => Yii::t('app', 'Chart Type'),
            'alias' => Yii::t('app', 'Alias'),
            'created' => Yii::t('app', 'Created'),
            'updated' => Yii::t('app', 'Updated'),
            'created_by' => Yii::t('app', 'Created By'),
            'updated_by' => Yii::t('app', 'Updated By'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNodeMeasureHistories()
    {
        return $this->hasMany(NodeMeasureHistory::className(), ['measure_code' => 'code']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNodeMeasureSettings()
    {
        return $this->hasMany(NodeMeasureSettings::className(), ['measure_code' => 'code']);
    }
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'updated_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'created_by']);
    }
      /**
     * @inheritdoc
     */
    public function beforeSave($insert)
    {
        if($insert){
            $this->created=date("Y-m-d H:i:s");
            $this->created_by=yii::$app->user->id;
        }
        $this->updated=date("Y-m-d H:i:s");
        $this->updated_by=yii::$app->user->id;
        return parent::beforeSave($insert);
    }
     /**
     * @return \yii\db\ActiveQuery
     */
    public function getStatusList($value='')
    {
        $list=[0=>Yii::t('app', 'Not Active'),1=>Yii::t('app', 'Active')];
        return ($value!='')?$list[$value]:$list;
    }
      /**
     * @return \yii\db\ActiveQuery
     */
    public function getTypeList($value='')
    {
        $list=[0=>Yii::t('app', 'Sensor'),1=>Yii::t('app', 'Actuator')];
        return ($value!=='')?$list[$value]:$list;
    }
}
