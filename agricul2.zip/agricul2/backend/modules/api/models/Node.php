<?php

namespace backend\modules\api\models;

use Yii;

/**
 * This is the model class for table "node".
 *
 * @property int $id
 * @property string $code
 * @property string $title
 * @property int $lng
 * @property int $lat
 * @property int $status
 * @property string $created
 * @property string $updated
 * @property int $created_by
 * @property int $updated_by
 *
 * @property NodeMeasureHistory[] $nodeMeasureHistories
 * @property NodeMeasureSettings[] $nodeMeasureSettings
 */
class Node extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'node';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['code', 'title', 'lng', 'lat', 'created', 'updated', 'created_by', 'updated_by'], 'required'],
            [['lng', 'lat', 'created_by', 'updated_by'], 'integer'],
            [['created', 'updated'], 'safe'],
            [['code', 'title'], 'string', 'max' => 255],
            [['status'], 'string', 'max' => 1],
            [['code'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'code' => Yii::t('app', 'Code'),
            'title' => Yii::t('app', 'Title'),
            'lng' => Yii::t('app', 'Lng'),
            'lat' => Yii::t('app', 'Lat'),
            'status' => Yii::t('app', 'Status'),
            'created' => Yii::t('app', 'Created'),
            'updated' => Yii::t('app', 'Updated'),
            'created_by' => Yii::t('app', 'Created By'),
            'updated_by' => Yii::t('app', 'Updated By'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNodeMeasureHistories()
    {
        return $this->hasMany(NodeMeasureHistory::className(), ['node_code' => 'code']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNodeMeasureSettings()
    {
        return $this->hasMany(NodeMeasureSettings::className(), ['node_code' => 'code']);
    }
}
