<?php

namespace backend\modules\api\controllers;

use Yii;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use app\modules\api\components\ApiAuth;
use app\modules\api\components\ApiResponse;
use yii\filters\ContentNegotiator;
use yii\web\Response;

use yii\web\ForbiddenHttpException;

use app\models\Node;

//use app\modules\api\components\FileUploader;
class NodeController extends \yii\web\Controller
{
    public function behaviors()
    {
        return [
            // 'authenticator' => [
            //     'class' => ApiAuth::className()
            // ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'me' => ['get'],
                    'all' => ['get'],
                    'client' => ['get'],
                    'create' => ['post'],
                    'update' => ['put']
                ]
            ],
            /* 'access' => [
                'class' => AccessControl::className(),
                'only' => ['me','all','client','create'],
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],*/
            'contentNegotiator' => [
                'class' => ContentNegotiator::className(),
                'formats' => [
                    'application/json' => Response::FORMAT_JSON,
                ],
            ]
        ];
    }

    public function actionMe($code)
    {
        $node = Node::findByCode($code);

        if (!$node) {
            return [
                'success' => 0,
                'payload' => 'Some error occurred'
            ];
        }

        return [
            'success' => 1,
            'payload' => $node
        ];
    }

    public function actionAll()
    {
        $nodes = Node::findAll([
            'status' => Node::ACTIVE
        ]);
        $node = new Node();
        $columns=$node->getColumns();
        $countPerPage=5;
        $data= array(
            "metadata"=> ApiResponse::getMetaData(),
            "pager"=> [
                "results"=>[
                    "total"=>count($nodes),
                    "per_page"=>$countPerPage
                ],
                "pages"=>[
                    "total"=>ceil(count($nodes)/$countPerPage),
                    "current"=>1
                ]
            ],
            "columns"=> $columns,
            "items"=> $nodes
        );
        return $data;
    }

    public function actionClient()
    {
        $projection = ['id','code',
            'title',
            'lng',
            'lat','status',];

        $node = Node::find()->where(
            'code = :code and status = :status', [
                ':code' => Yii::$app->request->getQueryParam('code'),
                ':status' => Node::ACTIVE
            ])->select($projection)->asArray()->one();

        return [
            'success' => 1,
            'payload' => $node
        ];
    }

    private function _addOrUpdate($params)
    {
        if ($params['code']) {
            $node = Node::findOne([
                'code' => $params['code']
            ]);

            if (!$node) {
                return [
                    'success' => 0,
                    'message' => 'No such node exist'
                ];
            }
        } else {
            $node = new Node();
        }

        $node->code = $params['code'];
        $node->title = $params['title'];
        $node->lng = $params['lng'];
        $node->lat = $params['lat'];
         $node->status= $params['status'];
        if (!$node->validate()) {
            return [
                'success' => 0,
                'message' => $node->getErrors()
            ];
        }      

        if (!$node->save()) {
            return [
                'success' => 0,
                'message' => 'Some error occurred'
            ];
        }

        return [
            'success' => 1,
            'payload' => $node
        ];
    }

    public function actionCreate()
    {
        return _addOrUpdate(Yii::$app->request->getBodyParams());
    }

    public function actionUpdate()
    {
        return _addOrUpdate(Yii::$app->request->getBodyParams());
    }
}
