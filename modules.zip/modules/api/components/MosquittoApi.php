<?php

/**
 * MosquittoApi Class
 */
namespace app\modules\api\components;

use Yii;

class MosquittoApi {
    public static $publish = array();
    public static $receive = array();
    public static function addPublish($mid, $msg) {
        $msg->id = $mid;
        self::$publish[$mid] = $msg;
    }
    public static function confirm($mid) {
        if(array_key_exists($mid, self::$publish)) {
            self::$publish[$mid]->state = true;
        }
    }
    public static function addReceive($msg) {
        $msg = MosquittoMsg::factory($msg, true);
        self::$receive[$msg->id] = $msg;
    }
}
class MosquittoMsg {
    public $id;
    public $state = false;
    public $msg;
    public static function factory(Mosquitto\Message $msg, $state = false) {
        $message = new MosquittoMsg();
        $message->state = $state;
        $message->msg = $msg;
        $message->id = $msg->mid;
        return $message;
    }
}
