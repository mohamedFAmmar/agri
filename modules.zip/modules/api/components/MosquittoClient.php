<?php
/**
 * MosquittoApi Class
 */
namespace app\modules\api\components;

use Yii;

class MosquittoClient extends Mosquitto\Client {

	protected $pendingSubs = [];
	protected $grantedSubs = [];

	protected $subscribeCallback = null;

	public function __construct($id = null, $cleanSession = false) {
		parent::__construct($id, $cleanSession);
		parent::onSubscribe(array($this, 'subscribeHandler'));
	}

	public function subscribeHandler($mid, $qosCount, $grantedQos) {
		if (!isset($this->pendingSubs[$mid])) {
			return;
		}

		$topic = $this->pendingSubs[$mid];
		$this->grantedSubs[$topic] = $grantedQos;
		echo "Subscribed to topic {$topic} with message ID {$mid}\n";

		if (is_callable($this->subscribeCallback)) {
			$this->subscribeCallback($mid, $qosCount, $grantedQos);
		}
	}

	public function subscribe($topic, $qos) {
		$mid = parent::subscribe($topic, $qos);
		$this->pendingSubs[$mid] = $topic;
	}

	public function onSubscribe(callable $callable) {
		$this->subscribeHandler = $callable;
	}

	public function getSubscriptions() {
		return $this->grantedSubs;
	}
}