<?php

namespace backend\modules\api\controllers;

use Yii;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use app\modules\api\components\ApiAuth;
use app\modules\api\components\ApiResponse;
use app\modules\api\components\MosquittoApi;
use app\modules\api\components\MosquittoClient;

use yii\filters\ContentNegotiator;
use yii\web\Response;

use yii\web\ForbiddenHttpException;

//use app\models\Menu;

//use app\modules\api\components\FileUploader;
class BrokerController extends \yii\web\Controller
{
    public function behaviors()
    {
        return [
            // 'authenticator' => [
            //     'class' => ApiAuth::className()
            // ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'sendMessage' => ['post'],
                    'createMessage' => ['post'],
                    'subscribeMessage'=>['get'],
                ]
            ],
            /* 'access' => [
                'class' => AccessControl::className(),
                'only' => ['me','all','client','create'],
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],*/
            'contentNegotiator' => [
                'class' => ContentNegotiator::className(),
                'formats' => [
                    'application/json' => Response::FORMAT_JSON,
                ],
            ]
        ];
    }

    public function actionSendMessage()
    {
        $data=$this->actionCreateMessage();
        $client = new Mosquitto\Client('client.terminal.onpublish', false);
        $client->onPublish(function($mid) {
            MosquittoApi::confirm($mid);
            print_r(array('comfirm publish', MosquittoApi::$publish[$mid]));
        });
        $client->onConnect(function($rc, $msg) {
            print_r(array('rc' => $rc, 'message' => $msg));
        });

        $client->connect('localhost', 1883, 60);
        sleep(1);

        $msg = MosquittoMsg::factory(new Mosquitto\Message());
        $msg->msg->topic = 'Gate';
        $msg->msg->payload = json_encode($data);
        $msg->msg->qos = 1;
        $mid = $client->publish($msg->msg->topic, $msg->msg->payload, $msg->msg->qos);
        print_r(array('publish', $msg));
        MosquittoApi::addPublish($mid, $msg);

       return true;
    
    }

    public function actionCreateMessage()
    {
        $data= array(
            "a"=> 1,"b"=>2
        );
        return $data;
    }
    public function actionSubscribeMessage()
    {
        $c = new MyClient('subscriptionTest');
        $c->onSubscribe(function() { echo "Hello, I got subscribed\n"; });
        $c->connect('localhost', 1883, 50);
        $c->subscribe('#', 1);

        for ($i = 0; $i < 5; $i++) {
            $c->loop(10);
        }

        var_dump($c->getSubscriptions());
    }
    
}
