<?php

namespace backend\modules\api\controllers;

use Yii;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use app\modules\api\components\ApiAuth;
use app\modules\api\components\ApiResponse;
use yii\filters\ContentNegotiator;
use yii\web\Response;

use yii\web\ForbiddenHttpException;

use app\models\UnitOfMeasure;

//use app\modules\api\components\FileUploader;
class UnitOfMeasureController extends \yii\web\Controller
{
    public function behaviors()
    {
        return [
            // 'authenticator' => [
            //     'class' => ApiAuth::className()
            // ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'me' => ['post'],
                    'all' => ['get'],
                    'client' => ['post'],
                    'create' => ['post'],
                    'update' => ['post']
                ]
            ],
            /* 'access' => [
                'class' => AccessControl::className(),
                'only' => ['me','all','client','create'],
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],*/
            'contentNegotiator' => [
                'class' => ContentNegotiator::className(),
                'formats' => [
                    'application/json' => Response::FORMAT_JSON,
                ],
            ]
        ];
    }

    public function actionMe()
    {
        $unitOfMeasure = UnitOfMeasure::findByCode((Yii::$app->request->getQueryParam('code')););

        if (!$unitOfMeasure) {
            return [
                'success' => 0,
                'payload' => 'Some error occurred'
            ];
        }

        return [
            'success' => 1,
            'payload' => $unitOfMeasure
        ];
    }

    public function actionAll()
    {
        $unitOfMeasures = UnitOfMeasure::findAll();
        $unitOfMeasure = new UnitOfMeasure();
        $columns=$unitOfMeasure->getColumns();
        $countPerPage=5;
        $data= array(
            "metadata"=> ApiResponse::getMetaData(),
            "pager"=> [
                "results"=>[
                    "total"=>count($unitOfMeasures),
                    "per_page"=>$countPerPage
                ],
                "pages"=>[
                    "total"=>ceil(count($unitOfMeasures)/$countPerPage),
                    "current"=>1
                ]
            ],
            "columns"=> $columns,
            "items"=> $unitOfMeasures
        );
        return $data;
    }

    public function actionClient()
    {
        $projection = ['id','code',
            'title',
            'alias',
            'status','type'];

        $unitOfMeasure = UnitOfMeasure::find()->where(
            'code = :code and status = :status', [
                ':code' => Yii::$app->request->getQueryParam('code'),
                ':status' => UnitOfMeasure::ACTIVE
            ])->select($projection)->asArray()->one();

        return [
            'success' => 1,
            'payload' => $unitOfMeasure
        ];
    }

    public function actionCreate()
    {
        return $this->_addOrUpdate(Yii::$app->request->getBodyParams());
    }

    public function actionUpdate()
    {
        return $this->_addOrUpdate(Yii::$app->request->getBodyParams(),1);
    }
    private function _addOrUpdate($params,$flag=0)
    {
        if ($flag) {
            $unitOfMeasure = UnitOfMeasure::findOne([
                'code' => $params['code']
            ]);

            if (!$unitOfMeasure) {
                return [
                    'success' => 0,
                    'message' => 'No such unitOfMeasure exist'
                ];
            }
        } else {
            $unitOfMeasure = new UnitOfMeasure();
        }

        $unitOfMeasure->code = $params['code'];
        $unitOfMeasure->title = $params['title'];
        $unitOfMeasure->alias = $params['alias'];
        $unitOfMeasure->type = $params['type'];
        $unitOfMeasure->status= $params['status'];
        if (!$unitOfMeasure->validate()) {
            return [
                'success' => 0,
                'message' => $unitOfMeasure->getErrors()
            ];
        }      

        if (!$unitOfMeasure->save()) {
            return [
                'success' => 0,
                'message' => 'Some error occurred'
            ];
        }

        return [
            'success' => 1,
            'payload' => $unitOfMeasure
        ];
    }
}
