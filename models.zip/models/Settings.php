<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "settings".
 *
 * @property int $id
 * @property string $setting_key
 * @property string $title
 * @property string $value
 */
class Settings extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'settings';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['setting_key', 'title', 'value'], 'required'],
            [['setting_key', 'title', 'value'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'setting_key' => Yii::t('app', 'Setting Key'),
            'title' => Yii::t('app', 'Title'),
            'value' => Yii::t('app', 'Value'),
        ];
    }
    /**
     * Finds user by setting_key
     *
     * @param string $setting_key
     * @return static|null
     */
    public static function findBySettingKey($setting_key)
    {
        return static::find()->where(
            'setting_key = :setting_key', [
                ':setting_key' => $setting_key
            ])->one();
    }

    public function getColumns(){
        $columns = [];
        $fields = $this->attributeLabels();
        unset($fields['id']);
        foreach ($fields as $field => $label) {
            $filterItems=[];
            array_push($columns, [
                "label"=>$label,
                "attribute"=> $field,
                "description"=> null,
                "options"=> [],
                "sortable"=>true,
                "filterable"=> true,
                "filter"=>[
                    "selected"=>null,
                    "items"=> $filterItems,
                    "options"=> []
                ],
                "header"=> [
                    "value"=> [],
                    "options"=> []
                ],
                "footer"=>[
                    "value"=> [],
                    "options"=> []
                ]
            ]);
        }
        return $columns; 
    }
}
