<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "menu".
 *
 * @property int $id
 * @property string $title
 * @property string $url
 * @property int $status
 * @property string $type
 * @property int $showed_in_menu
 * @property int $parent_id
 * @property string $created
 * @property string $updated
 */
class Menu extends \yii\db\ActiveRecord
{
    const INACTIVE = 0;
    const ACTIVE = 1;
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'menu';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['title', 'url', 'type', 'parent_id'], 'required'],
            [['parent_id'], 'integer'],
            [['created', 'updated'], 'safe'],
            [['title', 'url', 'type'], 'string', 'max' => 255],
            [['status', 'showed_in_menu'], 'string', 'max' => 1],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'title' => Yii::t('app', 'Title'),
            'url' => Yii::t('app', 'Url'),
            'status' => Yii::t('app', 'Status'),
            'type' => Yii::t('app', 'Type'),
            'showed_in_menu' => Yii::t('app', 'Showed In Menu'),
            'parent_id' => Yii::t('app', 'Parent ID'),
            'created' => Yii::t('app', 'Created'),
            'updated' => Yii::t('app', 'Updated'),
        ];
    }
    /**
     * @inheritdoc
     */
    public function beforeSave($insert)
    {
        if($insert)
            $this->created=date("Y-m-d H:i:s");
        $this->updated=date("Y-m-d H:i:s");
        return parent::beforeSave($insert);
    }
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getStatusList($value='')
    {
        $list=[0=>Yii::t('app', 'Not Active'),1=>Yii::t('app', 'Active')];
        return ($value!='')?$list[$value]:$list;
    }
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getShowedInMenuList($value='')
    {
        $list=[0=>Yii::t('app', 'No'),1=>Yii::t('app', 'Yes')];
        return ($value!='')?$list[$value]:$list;
    }
    /**
     * Finds user by title
     *
     * @param string $title
     * @return static|null
     */
    public static function findByTitle($title)
    {
        return static::find()->where(
            'title = :title and status = :status', [
                ':title' => $title,
                ':status' => self::ACTIVE
            ])->one();
    }

    public function getColumns(){
        $columns = [];
        $fields = $this->attributeLabels();
        unset($fields['id']);
        foreach ($fields as $field => $label) {
            $filterItems=[];
            switch ($field) {
                case 'status':
                    $filterItems=$this->getStatusList();
                    break;
                case 'created_by':
                case 'updated_by':
                    $filterItems=[];
                    break;
                default:
                    # code...
                    break;
            }
            array_push($columns, [
                "label"=>$label,
                "attribute"=> $field,
                "description"=> null,
                "options"=> [],
                "sortable"=>true,
                "filterable"=> true,
                "filter"=>[
                    "selected"=>null,
                    "items"=> $filterItems,
                    "options"=> []
                ],
                "header"=> [
                    "value"=> [],
                    "options"=> []
                ],
                "footer"=>[
                    "value"=> [],
                    "options"=> []
                ]
            ]);
        }
        return $columns; 
    }
}
