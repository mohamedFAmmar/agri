<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "roles".
 *
 * @property int $id
 * @property string $alias
 * @property string $title
 * @property int $status
 *
 * @property User[] $users
 */
class Roles extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'roles';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['alias', 'title'], 'required'],
            [['alias', 'title'], 'string', 'max' => 255],
            [['status'], 'safe'],
            [['alias'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'alias' => Yii::t('app', 'Alias'),
            'title' => Yii::t('app', 'Title'),
            'status' => Yii::t('app', 'Status'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUsers()
    {
        return $this->hasMany(User::className(), ['role_id' => 'id']);
    }
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getStatusList($value='')
    {
        $list=[0=>Yii::t('app', 'Not Active'),1=>Yii::t('app', 'Active')];
        return ($value!='')?$list[$value]:$list;
    }
    /**
     * Finds user by alias
     *
     * @param string $alias
     * @return static|null
     */
    public static function findByAlias($alias)
    {
        return static::find()->where(
            'alias = :alias and status = :status', [
                ':alias' => $alias,
                ':status' => self::ACTIVE
            ])->one();
    }

    public function getColumns(){
        $columns = [];
        $fields = $this->attributeLabels();
        unset($fields['id']);
        foreach ($fields as $field => $label) {
            $filterItems=[];
            switch ($field) {
                case 'status':
                    $filterItems=$this->getStatusList();
                    break;
                case 'created_by':
                case 'updated_by':
                    $filterItems=[];
                    break;
                default:
                    # alias...
                    break;
            }
            array_push($columns, [
                "label"=>$label,
                "attribute"=> $field,
                "description"=> null,
                "options"=> [],
                "sortable"=>true,
                "filterable"=> true,
                "filter"=>[
                    "selected"=>null,
                    "items"=> $filterItems,
                    "options"=> []
                ],
                "header"=> [
                    "value"=> [],
                    "options"=> []
                ],
                "footer"=>[
                    "value"=> [],
                    "options"=> []
                ]
            ]);
        }
        return $columns; 
    }
}
