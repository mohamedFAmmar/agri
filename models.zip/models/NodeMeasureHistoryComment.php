<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "node_measure_history_comment".
 *
 * @property string $id
 * @property string $node_measure_history_id
 * @property string $message
 * @property int $status
 * @property string $created
 * @property int $created_by
 *
 * @property NodeMeasureHistory $nodeMeasureHistory
 * @property User $createdBy
 */
class NodeMeasureHistoryComment extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'node_measure_history_comment';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['node_measure_history_id', 'message', 'created', 'created_by'], 'required'],
            [['node_measure_history_id', 'created_by'], 'integer'],
            [['message'], 'string'],
            [['created'], 'safe'],
            [['status'], 'string', 'max' => 1],
            [['node_measure_history_id'], 'exist', 'skipOnError' => true, 'targetClass' => NodeMeasureHistory::className(), 'targetAttribute' => ['node_measure_history_id' => 'id']],
            [['created_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['created_by' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'node_measure_history_id' => Yii::t('app', 'Node Measure History ID'),
            'message' => Yii::t('app', 'Message'),
            'status' => Yii::t('app', 'Status'),
            'created' => Yii::t('app', 'Created'),
            'created_by' => Yii::t('app', 'Created By'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNodeMeasureHistory()
    {
        return $this->hasOne(NodeMeasureHistory::className(), ['id' => 'node_measure_history_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'created_by']);
    }
}
