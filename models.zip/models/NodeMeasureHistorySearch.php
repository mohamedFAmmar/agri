<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\NodeMeasureHistory;

/**
 * NodeMeasureHistorySearch represents the model behind the search form of `app\models\NodeMeasureHistory`.
 */
class NodeMeasureHistorySearch extends NodeMeasureHistory
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'created_by', 'updated_by'], 'integer'],
            [['node_code', 'measure_code', 'measure_type', 'status', 'created', 'updated', 'date'], 'safe'],
            [['value', 'min_value', 'max_value'], 'number'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = NodeMeasureHistory::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'value' => $this->value,
            'min_value' => $this->min_value,
            'max_value' => $this->max_value,
            'created' => $this->created,
            'updated' => $this->updated,
            'created_by' => $this->created_by,
            'updated_by' => $this->updated_by,
            'date' => $this->date,
        ]);

        $query->andFilterWhere(['like', 'node_code', $this->node_code])
            ->andFilterWhere(['like', 'measure_code', $this->measure_code])
            ->andFilterWhere(['like', 'measure_type', $this->measure_type])
            ->andFilterWhere(['like', 'status', $this->status]);

        return $dataProvider;
    }
}
