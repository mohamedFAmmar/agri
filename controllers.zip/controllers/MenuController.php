<?php

namespace backend\modules\api\controllers;

use Yii;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use app\modules\api\components\ApiAuth;
use app\modules\api\components\ApiResponse;
use yii\filters\ContentNegotiator;
use yii\web\Response;

use yii\web\ForbiddenHttpException;

use app\models\Menu;

//use app\modules\api\components\FileUploader;
class MenuController extends \yii\web\Controller
{
    public function behaviors()
    {
        return [
            // 'authenticator' => [
            //     'class' => ApiAuth::className()
            // ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'me' => ['get'],
                    'all' => ['get'],
                    'client' => ['get'],
                    'create' => ['post'],
                    'update' => ['put']
                ]
            ],
            /* 'access' => [
                'class' => AccessControl::className(),
                'only' => ['me','all','client','create'],
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],*/
            'contentNegotiator' => [
                'class' => ContentNegotiator::className(),
                'formats' => [
                    'application/json' => Response::FORMAT_JSON,
                ],
            ]
        ];
    }

    public function actionMe($title)
    {
        $menu = Menu::findByTitle($title);

        if (!$menu) {
            return [
                'success' => 0,
                'payload' => 'Some error occurred'
            ];
        }

        return [
            'success' => 1,
            'payload' => $menu
        ];
    }

    public function actionAll()
    {
        $menus = Menu::findAll([
            'status' => Menu::ACTIVE
        ]);
        $menu = new Menu();
        $columns=$menu->getColumns();
        $countPerPage=5;
        $data= array(
            "metadata"=> ApiResponse::getMetaData(),
            "pager"=> [
                "results"=>[
                    "total"=>count($menus),
                    "per_page"=>$countPerPage
                ],
                "pages"=>[
                    "total"=>ceil(count($menus)/$countPerPage),
                    "current"=>1
                ]
            ],
            "columns"=> $columns,
            "items"=> $menus
        );
        return $data;
    }

    public function actionClient()
    {
        $projection = ['id',
            'title',
            'url',
            'status',];

        $menu = Menu::find()->where(
            'title = :title and status = :status', [
                ':title' => Yii::$app->request->getQueryParam('title'),
                ':status' => Menu::ACTIVE
            ])->select($projection)->asArray()->one();

        return [
            'success' => 1,
            'payload' => $menu
        ];
    }

    private function _addOrUpdate($params)
    {
        if ($params['title']) {
            $menu = Menu::findOne([
                'title' => $params['title']
            ]);

            if (!$menu) {
                return [
                    'success' => 0,
                    'message' => 'No such menu exist'
                ];
            }
        } else {
            $menu = new Menu();
        }

        $menu->url = $params['url'];
        $menu->title = $params['title'];
        $menu->status= $params['status'];

        if (!$menu->validate()) {
            return [
                'success' => 0,
                'message' => $menu->getErrors()
            ];
        }      

        if (!$menu->save()) {
            return [
                'success' => 0,
                'message' => 'Some error occurred'
            ];
        }

        return [
            'success' => 1,
            'payload' => $menu
        ];
    }

    public function actionCreate()
    {
        return _addOrUpdate(Yii::$app->request->getBodyParams());
    }

    public function actionUpdate()
    {
        $params=Yii::$app->request->getBodyParams();
        if ($params['title'] && count($params)<=1) {
            return actionMe($params['title']);
        }
        return _addOrUpdate(Yii::$app->request->getBodyParams());
    }
}
