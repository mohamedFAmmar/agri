<?php

namespace backend\modules\api\controllers;

use Yii;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use app\modules\api\components\ApiAuth;
use app\modules\api\components\ApiResponse;
use yii\filters\ContentNegotiator;
use yii\web\Response;

use yii\web\ForbiddenHttpException;

use app\models\NodeMeasureHistory;

//use app\modules\api\components\FileUploader;
class NodeMeasureHistoryController extends \yii\web\Controller
{
    public function behaviors()
    {
        return [
            // 'authenticator' => [
            //     'class' => ApiAuth::className()
            // ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'me' => ['get'],
                    'all' => ['get'],
                    'client' => ['get'],
                    'create' => ['post'],
                    'update' => ['put']
                ]
            ],
            /* 'access' => [
                'class' => AccessControl::className(),
                'only' => ['me','all','client','create'],
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],*/
            'contentNegotiator' => [
                'class' => ContentNegotiator::className(),
                'formats' => [
                    'application/json' => Response::FORMAT_JSON,
                ],
            ]
        ];
    }

    public function actionMe($params)
    {
        $nodeMeasureHistory = NodeMeasureHistory::findByCodes($params)->orderBy(['date' => SORT_DESC]);

        if (!$nodeMeasureHistory) {
            return [
                'success' => 0,
                'payload' => 'Some error occurred'
            ];
        }

        return [
            'success' => 1,
            'payload' => $nodeMeasureHistory
        ];
    }

    public function actionAll()
    {
        $nodeMeasureHistorys = NodeMeasureHistory::findAll()->orderBy(['date' => SORT_DESC]);
        $nodeMeasureHistory = new NodeMeasureHistory();
        $columns=$nodeMeasureHistory->getColumns();
        $countPerPage=5;
        $data= array(
            "metadata"=> ApiResponse::getMetaData(),
            "pager"=> [
                "results"=>[
                    "total"=>count($nodeMeasureHistorys),
                    "per_page"=>$countPerPage
                ],
                "pages"=>[
                    "total"=>ceil(count($nodeMeasureHistorys)/$countPerPage),
                    "current"=>1
                ]
            ],
            "columns"=> $columns,
            "items"=> $nodeMeasureHistorys
        );
        return $data;
    }

    public function actionClient()
    {
        $projection = ['id' ,
            'node_code',
            'measure_code' ,
            'measure_type' ,
            'value' ,
            'min_value' ,
            'max_value' ,
            'status' ,
            'created' ,
            'updated' ,
            'date' ,
        ];
        $nodeMeasureHistory = NodeMeasureHistory::find()->where(
            'node_code = :node_code and measure_code = :measure_code', [
                ':node_code' => Yii::$app->request->getQueryParam('node_code'),
                ':measure_code' =>Yii::$app->request->getQueryParam('measure_code')
            ])->select($projection)->asArray()->orderBy(['date' => SORT_DESC])->one();

        return [
            'success' => 1,
            'payload' => $nodeMeasureHistory
        ];
    }

    private function _addOrUpdate($params)
    {
        if ($params['node_code'] && $params['measure_code'] ) {
            $nodeMeasureHistory = NodeMeasureHistory::findOne([
                'node_code' => $params['node_code'],
                'measure_code' => $params['measure_code']
            ])->orderBy(['date' => SORT_DESC]);

            if (!$nodeMeasureHistory) {
                return [
                    'success' => 0,
                    'message' => 'No such nodeMeasureHistory exist'
                ];
            }
        } else {
            $nodeMeasureHistory = new NodeMeasureHistory();
        }
        $nodeMeasureHistory->node_code = $params['node_code'];
        $nodeMeasureHistory->measure_code= $params['measure_code'];
        $nodeMeasureHistory->measure_type= $params['measure_type'];
        $nodeMeasureHistory->value= $params['value'];
        $nodeMeasureHistory->min_value= $params['min_value'];
        $nodeMeasureHistory->max_value= $params['max_value'];
        $nodeMeasureHistory->status= $params['status'];
        $nodeMeasureHistory->date= $params['date'];

        if (!$nodeMeasureHistory->validate()) {
            return [
                'success' => 0,
                'message' => $nodeMeasureHistory->getErrors()
            ];
        }      

        if (!$nodeMeasureHistory->save()) {
            return [
                'success' => 0,
                'message' => 'Some error occurred'
            ];
        }

        return [
            'success' => 1,
            'payload' => $nodeMeasureHistory
        ];
    }

    public function actionCreate()
    {
        return _addOrUpdate(Yii::$app->request->getBodyParams());
    }

    public function actionUpdate()
    {
        $params=Yii::$app->request->getBodyParams();
        if ($params['node_code'] && $params['measure_code'] && count($params)<=2) {
            return actionMe($params);
        }
        return _addOrUpdate(Yii::$app->request->getBodyParams());
    }
}
