<?php

namespace backend\modules\api\controllers;

use Yii;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use app\modules\api\components\ApiAuth;
use app\modules\api\components\ApiResponse;
use yii\filters\ContentNegotiator;
use yii\web\Response;

use yii\web\ForbiddenHttpException;

use app\models\NodeMeasureSettings;

//use app\modules\api\components\FileUploader;
class NodeMeasureSettingsController extends \yii\web\Controller
{
    public function behaviors()
    {
        return [
            // 'authenticator' => [
            //     'class' => ApiAuth::className()
            // ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'me' => ['get'],
                    'all' => ['get'],
                    'client' => ['get'],
                    'create' => ['post'],
                    'update' => ['put']
                ]
            ],
            /* 'access' => [
                'class' => AccessControl::className(),
                'only' => ['me','all','client','create'],
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],*/
            'contentNegotiator' => [
                'class' => ContentNegotiator::className(),
                'formats' => [
                    'application/json' => Response::FORMAT_JSON,
                ],
            ]
        ];
    }

    public function actionMe($params)
    {
        $nodeMeasureSetting = NodeMeasureSettings::findByCodes($params)->orderBy(['date' => SORT_DESC]);

        if (!$nodeMeasureSetting) {
            return [
                'success' => 0,
                'payload' => 'Some error occurred'
            ];
        }

        return [
            'success' => 1,
            'payload' => $nodeMeasureSetting
        ];
    }

    public function actionAll()
    {
        $nodeMeasureSettings = NodeMeasureSettings::findAll()->orderBy(['date' => SORT_DESC]);
        $nodeMeasureSetting = new NodeMeasureSettings();
        $columns=$nodeMeasureSetting->getColumns();
        $countPerPage=5;
        $data= array(
            "metadata"=> ApiResponse::getMetaData(),
            "pager"=> [
                "results"=>[
                    "total"=>count($nodeMeasureSettings),
                    "per_page"=>$countPerPage
                ],
                "pages"=>[
                    "total"=>ceil(count($nodeMeasureSettings)/$countPerPage),
                    "current"=>1
                ]
            ],
            "columns"=> $columns,
            "items"=> $nodeMeasureSettings
        );
        return $data;
    }

    public function actionClient()
    {
        $projection = ['id' ,
            'node_code',
            'measure_code' ,
            'measure_type' ,
            'value' ,
            'min_value' ,
            'max_value' ,
            'status' ,
            'created' ,
            'updated' ,
            'date' ,
        ];
        $nodeMeasureSetting = NodeMeasureSettings::find()->where(
            'node_code = :node_code and measure_code = :measure_code', [
                ':node_code' => Yii::$app->request->getQueryParam('node_code'),
                ':measure_code' =>Yii::$app->request->getQueryParam('measure_code')
            ])->select($projection)->asArray()->orderBy(['date' => SORT_DESC])->one();

        return [
            'success' => 1,
            'payload' => $nodeMeasureSetting
        ];
    }

    private function _addOrUpdate($params)
    {
        if ($params['node_code'] && $params['measure_code'] ) {
            $nodeMeasureSetting = NodeMeasureSettings::findOne([
                'node_code' => $params['node_code'],
                'measure_code' => $params['measure_code']
            ])->orderBy(['date' => SORT_DESC]);

            if (!$nodeMeasureSetting) {
                return [
                    'success' => 0,
                    'message' => 'No such nodeMeasureSetting exist'
                ];
            }
        } else {
            $nodeMeasureSetting = new NodeMeasureSettings();
        }
        $nodeMeasureSetting->node_code = $params['node_code'];
        $nodeMeasureSetting->measure_code= $params['measure_code'];
        $nodeMeasureSetting->measure_type= $params['measure_type'];
        $nodeMeasureSetting->value= $params['value'];
        $nodeMeasureSetting->min_value= $params['min_value'];
        $nodeMeasureSetting->max_value= $params['max_value'];
        $nodeMeasureSetting->status= $params['status'];
        $nodeMeasureSetting->date= $params['date'];

        if (!$nodeMeasureSetting->validate()) {
            return [
                'success' => 0,
                'message' => $nodeMeasureSetting->getErrors()
            ];
        }      

        if (!$nodeMeasureSetting->save()) {
            return [
                'success' => 0,
                'message' => 'Some error occurred'
            ];
        }

        return [
            'success' => 1,
            'payload' => $nodeMeasureSetting
        ];
    }

    public function actionCreate()
    {
        return _addOrUpdate(Yii::$app->request->getBodyParams());
    }

    public function actionUpdate()
    {
        $params=Yii::$app->request->getBodyParams();
        if ($params['node_code'] && $params['measure_code'] && count($params)<=2) {
            return actionMe($params);
        }
        return _addOrUpdate(Yii::$app->request->getBodyParams());
    }
}
