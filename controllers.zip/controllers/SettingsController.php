<?php

namespace backend\modules\api\controllers;

use Yii;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use app\modules\api\components\ApiAuth;
use app\modules\api\components\ApiResponse;
use yii\filters\ContentNegotiator;
use yii\web\Response;

use yii\web\ForbiddenHttpException;

use app\models\Settings;

//use app\modules\api\components\FileUploader;
class SettingsController extends \yii\web\Controller
{
    public function behaviors()
    {
        return [
            // 'authenticator' => [
            //     'class' => ApiAuth::className()
            // ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'me' => ['post'],
                    'all' => ['get'],
                    'client' => ['post'],
                    'create' => ['post'],
                    'update' => ['post']
                ]
            ],
            /* 'access' => [
                'class' => AccessControl::className(),
                'only' => ['me','all','client','create'],
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],*/
            'contentNegotiator' => [
                'class' => ContentNegotiator::className(),
                'formats' => [
                    'application/json' => Response::FORMAT_JSON,
                ],
            ]
        ];
    }

    public function actionMe()
    {
        $settings = Settings::findBySettingKey(Yii::$app->request->getQueryParam('setting_key'));

        if (!$settings) {
            return [
                'success' => 0,
                'payload' => 'Some error occurred'
            ];
        }

        return [
            'success' => 1,
            'payload' => $settings
        ];
    }

    public function actionAll()
    {
        $settings = Settings::findAll('1');
        $setting = new Settings();
        $columns=$setting->getColumns();
        $countPerPage=5;
        $data= array(
            "metadata"=> ApiResponse::getMetaData(),
            "pager"=> [
                "results"=>[
                    "total"=>count($settings),
                    "per_page"=>$countPerPage
                ],
                "pages"=>[
                    "total"=>ceil(count($settings)/$countPerPage),
                    "current"=>1
                ]
            ],
            "columns"=> $columns,
            "items"=> $settings
        );
        return $data;
    }

    public function actionClient()
    {
        $projection = ['id','setting_key',
            'title',
            'value',];

        $settings = Settings::find()->where(
            'setting_key = :setting_key and status = :status', [
                ':setting_key' => Yii::$app->request->getQueryParam('setting_key')
                
            ])->select($projection)->asArray()->one();

        return [
            'success' => 1,
            'payload' => $settings
        ];
    }
    public function actionCreate()
    {
        return $this->_addOrUpdate(Yii::$app->request->getBodyParams());
    }

    public function actionUpdate()
    {
        return $this->_addOrUpdate(Yii::$app->request->getBodyParams(),1);
    }
    private function _addOrUpdate($params,$flag=0)
    {
        if ($flag) {
            $settings = Settings::findOne([
                'setting_key' => $params['setting_key']
            ]);

            if (!$settings) {
                return [
                    'success' => 0,
                    'message' => 'No such settings exist'
                ];
            }
        } else {
            $settings = new Settings();
        }

        $settings->setting_key = $params['setting_key'];
        $settings->title = $params['title'];
        $settings->value = $params['value'];
        if (!$settings->validate()) {
            return [
                'success' => 0,
                'message' => $settings->getErrors()
            ];
        }      

        if (!$settings->save()) {
            return [
                'success' => 0,
                'message' => 'Some error occurred'
            ];
        }

        return [
            'success' => 1,
            'payload' => $settings
        ];
    }
}
