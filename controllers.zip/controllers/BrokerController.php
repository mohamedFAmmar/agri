<?php

namespace backend\modules\api\controllers;

use Yii;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use app\modules\api\components\ApiAuth;
use app\modules\api\components\ApiResponse;
use yii\filters\ContentNegotiator;
use yii\web\Response;

use yii\web\ForbiddenHttpException;

//use app\models\Menu;

//use app\modules\api\components\FileUploader;
class BrokerController extends \yii\web\Controller
{
    public function behaviors()
    {
        return [
            // 'authenticator' => [
            //     'class' => ApiAuth::className()
            // ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'getMessage' => ['post'],
                    'createMessage' => ['post'],
                ]
            ],
            /* 'access' => [
                'class' => AccessControl::className(),
                'only' => ['me','all','client','create'],
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],*/
            'contentNegotiator' => [
                'class' => ContentNegotiator::className(),
                'formats' => [
                    'application/json' => Response::FORMAT_JSON,
                ],
            ]
        ];
    }

    public function actionGetMessage()
    {
        $params=Yii::$app->request->getBodyParams());
        if (!$params) {
            return [
                'success' => 0,
                'payload' => 'Some error occurred'
            ];
        }
        return [
            'success' => 1,
            'payload' => $params
        ];
    }

    public function actionCreateMessage()
    {
        $menus = Menu::findAll([
            'status' => Menu::ACTIVE
        ]);
        $menu = new Menu();
        $columns=$menu->getColumns();
        $countPerPage=5;
        $data= array(
            "metadata"=> ApiResponse::getMetaData(),
            "pager"=> [
                "results"=>[
                    "total"=>count($menus),
                    "per_page"=>$countPerPage
                ],
                "pages"=>[
                    "total"=>ceil(count($menus)/$countPerPage),
                    "current"=>1
                ]
            ],
            "columns"=> $columns,
            "items"=> $menus
        );
        return $data;
    }

    
}
